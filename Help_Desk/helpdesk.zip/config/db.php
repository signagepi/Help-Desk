<?php
$host = 'sql100.byetcluster.com';
$db = 'if0_40238969_info';
$user = 'if0_40238969';
$pass = 'Fboz043175';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}
?>