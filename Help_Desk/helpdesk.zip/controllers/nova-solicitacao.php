<?php
session_start();
require '../config/db.php';
require_once __DIR__ . '/telegram-alertas-funcoes.php';

if (!isset($_SESSION['cliente_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

function limparTexto($valor) {
    return trim((string)($valor ?? ''));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../views/cliente/solicitar.php');
    exit;
}

$cliente_id = (int)$_SESSION['cliente_id'];
$titulo = limparTexto($_POST['titulo'] ?? '');
$descricao = limparTexto($_POST['descricao'] ?? '');
$categoria = limparTexto($_POST['categoria'] ?? 'Suporte técnico');
$prioridade = limparTexto($_POST['prioridade'] ?? 'media');
$equipamento = limparTexto($_POST['equipamento'] ?? '');
$local_atendimento = limparTexto($_POST['local_atendimento'] ?? '');

$prioridadesPermitidas = ['baixa', 'media', 'alta', 'urgente'];
if (!in_array($prioridade, $prioridadesPermitidas, true)) {
    $prioridade = 'media';
}

if ($descricao === '') {
    $_SESSION['error_msg'] = 'Descreva o problema ou serviço solicitado.';
    header('Location: ../views/cliente/solicitar.php');
    exit;
}

if ($titulo === '') {
    $titulo = mb_substr($descricao, 0, 120, 'UTF-8');
}

// SLA simples por prioridade
$horasSla = [
    'baixa' => 72,
    'media' => 48,
    'alta' => 24,
    'urgente' => 8,
];
$prazo = date('Y-m-d H:i:s', strtotime('+' . $horasSla[$prioridade] . ' hours'));

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("INSERT INTO solicitacoes
        (cliente_id, titulo, descricao, categoria, prioridade, canal, equipamento, local_atendimento, status, data, prazo, atualizado_em)
        VALUES (?, ?, ?, ?, ?, 'Portal do cliente', ?, ?, 'pendente', NOW(), ?, NOW())");
    $stmt->execute([$cliente_id, $titulo, $descricao, $categoria, $prioridade, $equipamento, $local_atendimento, $prazo]);

    $id = (int)$pdo->lastInsertId();
    $protocolo = 'INF-' . date('Y') . '-' . str_pad((string)$id, 5, '0', STR_PAD_LEFT);

    $stmt = $pdo->prepare("UPDATE solicitacoes SET protocolo = ? WHERE id = ?");
    $stmt->execute([$protocolo, $id]);

    $stmt = $pdo->prepare("INSERT INTO solicitacao_atividades (solicitacao_id, usuario_tipo, usuario_id, acao, descricao) VALUES (?, 'cliente', ?, 'abertura', ?)");
    $stmt->execute([$id, $cliente_id, 'Solicitação aberta pelo portal do cliente.']);

    $pdo->commit();

    try {
        enviarAlertaNovoChamado($pdo, $id);
    } catch (Throwable $alertaErro) {
        error_log('Erro ao enviar alerta Telegram: ' . $alertaErro->getMessage());
    }

    $_SESSION['success_msg'] = 'Solicitação aberta com sucesso! Protocolo: ' . $protocolo;
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Erro ao criar solicitação: ' . $e->getMessage());
    $_SESSION['error_msg'] = 'Não foi possível abrir a solicitação. Confirme se executou o SQL de modernização.';
    header('Location: ../views/cliente/solicitar.php');
    exit;
}

header('Location: ../views/cliente/dashboard.php');
exit;
