
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-fill]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const target = document.querySelector(btn.getAttribute('data-target') || '#descricao');
      if (target) { target.value = btn.getAttribute('data-fill'); target.dispatchEvent(new Event('input')); target.focus(); }
    });
  });
  document.querySelectorAll('[data-counter]').forEach(function (el) {
    const out = document.querySelector(el.getAttribute('data-counter'));
    const update = () => { if (out) out.textContent = el.value.length; };
    el.addEventListener('input', update); update();
  });
  document.querySelectorAll('[data-logo-preview]').forEach(function (input) {
    input.addEventListener('change', function () {
      const box = document.querySelector(input.getAttribute('data-logo-preview'));
      const file = input.files && input.files[0];
      if (!box || !file) return;
      const reader = new FileReader();
      reader.onload = e => { box.innerHTML = '<img src="' + e.target.result + '" alt="Prévia da logo">'; };
      reader.readAsDataURL(file);
    });
  });
});
function imprimirRelatorio(){ window.print(); }
